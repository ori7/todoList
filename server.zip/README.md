to run: 

* npm i in the client side and in the server side.

* ng serve in client side.

* npm start in server side.