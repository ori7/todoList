export interface FamilyMemberModel{
    id: number;
    name: string;
    nickname: string;
    description: string;
}