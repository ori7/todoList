export interface TodoModel{
    id: number;
    description: string;
    date: Date;
    familyId: number;
    name: string;
}